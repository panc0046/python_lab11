from flask_wtf import Form
from wtforms import SelectField, SubmitField

class ContactForm(Form):
    students = SelectField('students', choices=[])
    submit = SubmitField("Send")