from flask import Flask, render_template, request, redirect, url_for
from studentForm import ContactForm
from database import *
import base64
import webbrowser

app = Flask(__name__)
app.secret_key = 'development key'

@app.route('/')
@app.route('/home')
def home():
    return render_template('defaultPage.html')

@app.route('/findStudent', methods= ['GET','POST'])
def findStudent():
    form = ContactForm()
    objDatabase = Database()
    value = objDatabase.main(1)
    form.students.choices = value
    return render_template('findStudent.html', form=form)

@app.route('/submitForm', methods=['GET','POST'])
def submitForm():
    result = request.form.get('students')
    decoded = base64.b64decode(result).decode("utf-8")
    webbrowser.open_new_tab(decoded)
    return redirect(url_for('findStudent'))

@app.route('/studentList')
def studentList():
    objDatabase = Database()
    value = objDatabase.main(2)
    return render_template('displayAll.html', value=value)



if __name__ == '__main__':
    app.run()
