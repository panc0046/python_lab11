import sqlite3
import base64

class Database:
    def createConnectionSql(self, db_file):
        connector = None
        dataCursor = None
        try:
            connector = sqlite3.connect(db_file)
            connector.row_factory = sqlite3.Row
            dataCursor = connector.cursor()
        except sqlite3.Error as e:
            print(e)

        return connector, dataCursor

    def getTotalNoOfRowsInDb(self, dataCursor1):
        dataCursor1.execute("select count(*) from Lab10")
        noOfRows = dataCursor1.fetchall()
        return int(noOfRows[0][0])

    def getAllDataFrmDb(self, dataCursor2, connector2):
        dataCursor2.execute('select * from Lab10')
        data = dataCursor2.fetchall()
        connector2.close()
        return data

    # listType = 1 for groupList & listType = 2 for all data
    def main(self, listType):
        dami = Database()
        connector, dataCursor = dami.createConnectionSql("week10.db")
        totalRows = dami.getTotalNoOfRowsInDb(dataCursor)
        value = dami.getAllDataFrmDb(dataCursor, connector)
        groupList = list()
        if listType == 1:
            groups_list = [(value[i][1], value[i][4]) for i in range(totalRows)]
        else:
            objDatabase = Database()
            groups_list = [(value[i][0], objDatabase.decode(value[i][1]), value[i][2], value[i][3], value[i][4]) for i in range(totalRows)]
        return groups_list

    def decode(self, link):
        decoded = base64.b64decode(link).decode("utf-8")
        return decoded